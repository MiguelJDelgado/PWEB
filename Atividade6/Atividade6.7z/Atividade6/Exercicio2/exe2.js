var num1 = parseFloat(prompt("Insira o primeiro numero"));
var num2 = parseFloat(prompt("Insira o segundo numero"));

    var soma = (num1 + num2);
    var subtracao= (num1 - num2);
    var produto = (num1 * num2);
    var divisao = (num1 / num2);
    var resto = (num1 % num2);

alert("Soma: " + soma);
alert("Subtracao: " + subtracao);
alert("Produto: " + produto);
alert("Divisao: " + divisao);
alert("Resto: " + resto);
