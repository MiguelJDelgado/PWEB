var nome = prompt ("Insira seu nome");
var nota1 = parseFloat(prompt("Insira a nota 1"));
var nota2 = parseFloat(prompt("Insira a nota 2"));
var nota3 = parseFloat(prompt("Insira a nota 3"));
var nota4 = parseFloat(prompt("Insira a nota 4"));

var media = () => {
    var mediafinal = (nota1 + nota2 + nota3 + nota4) / 4;
    return mediafinal;
}

alert("A média das 4 notas do " + nome + " é: " + media());