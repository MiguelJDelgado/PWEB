function validar(event) {
    event.preventDefault();
  
    const form = document.nomeform;
    const nome = form.elements["nome"].value.trim();
    const email = form.elements["email"].value.trim();
    const comentario = form.elements["comentario"].value.trim();
  
    if (nome.length < 10) {
      alert("O nome deve ter pelo menos 10 caracteres.");
      return false;
    }
  
    if (comentario.length < 20) {
      alert("O comentário deve ter no mínimo 20 caracteres.");
      return false;
    }
  
    const radios = form.elements["pesquisa"];
    let selecionado = false;
    let valorSelecionado = "";
  
    for (let i = 0; i < radios.length; i++) {
      if (radios[i].checked) {
        selecionado = true;
        valorSelecionado = radios[i].value;
        break;
      }
    }
  
    if (!selecionado) {
      alert("Por favor, selecione uma opção de pesquisa.");
      return false;
    }
  
    if (valorSelecionado === "nao") {
      alert("Que bom que você voltou a visitar esta página!");
    } else {
      alert("Volte sempre à esta página!");
    }
  
    alert("Formulário enviado com sucesso!");
    return true;
  }
  