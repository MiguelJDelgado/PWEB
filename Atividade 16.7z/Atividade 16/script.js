function abrirCurso(valor) {
    if (valor === "") return;
  
    const cursos = {
      ads: "Análise e Desenvolvimento de Sistemas: curso voltado para programação, banco de dados e desenvolvimento de software.",
      logistica: "Logística: formação voltada à gestão da cadeia de suprimentos e processos logísticos.",
      mecatronica: "Mecatrônica Industrial: integra mecânica, eletrônica e automação industrial.",
      gestaoTI: "Gestão da Tecnologia da Informação: forma profissionais para gestão de recursos de TI.",
      fabricacao: "Fabricação Mecânica: foca em processos de manufatura e controle de qualidade industrial."
    };
  
    const confirmar = window.confirm("Deseja abrir as informações sobre este curso?");
    
    if (confirmar) {
      const janela = window.open("", "cursoInfo", "width=600,height=300");
      janela.document.write(`
        <html>
          <head>
            <title>Informações do Curso</title>
            <style>
              body { font-family: Arial; padding: 20px; background-color: #eef; }
              h2 { color: #003366; }
            </style>
          </head>
          <body>
            <h2>Curso Selecionado</h2>
            <p>${cursos[valor]}</p>
          </body>
        </html>
      `);
    }
  }
  