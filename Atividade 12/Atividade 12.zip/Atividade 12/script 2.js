function Retangulo(base, altura) {
    this.base = base;
    this.altura = altura;

    this.calcularArea = function() {
        return this.base * this.altura;
    };
}

// Função para calcular a área do Retângulo
function calcularAreaRetangulo() {
    const base = parseFloat(document.getElementById('baseRetangulo').value);
    const altura = parseFloat(document.getElementById('alturaRetangulo').value);

    const retangulo = new Retangulo(base, altura);
    const area = retangulo.calcularArea();
    document.getElementById('resultadoRetangulo').innerHTML = `<p>A área do retângulo é: <strong>${area} unidades quadradas</strong>.</p>`;
}

// Classe Conta
class Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo) {
        this.nomeCorrentista = nomeCorrentista;
        this.banco = banco;
        this.numeroConta = numeroConta;
        this.saldo = saldo;
    }

    exibirDados() {
        return `
            <ul>
                <li><span>Correntista:</span> ${this.nomeCorrentista}</li>
                <li><span>Banco:</span> ${this.banco}</li>
                <li><span>Conta:</span> ${this.numeroConta}</li>
                <li><span>Saldo:</span> R$ ${this.saldo.toFixed(2)}</li>
            </ul>
        `;
    }
}

// Classe Corrente
class Corrente extends Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo) {
        super(nomeCorrentista, banco, numeroConta, saldo);
        this.tipoConta = "Corrente";
    }
}

// Classe Poupanca
class Poupanca extends Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo, juros, dataVencimento) {
        super(nomeCorrentista, banco, numeroConta, saldo);
        this.tipoConta = "Poupança";
        this.juros = juros;
        this.dataVencimento = dataVencimento;
    }

    exibirDados() {
        let dados = super.exibirDados();
        dados += `
            <li><span>Juros:</span> ${this.juros}%</li>
            <li><span>Data de Vencimento:</span> ${this.dataVencimento}</li>
        `;
        return dados;
    }
}

// Função para Criar Conta Corrente
function criarContaCorrente() {
    const nome = document.getElementById('nomeCorrente').value;
    const banco = document.getElementById('bancoCorrente').value;
    const numeroConta = document.getElementById('numeroContaCorrente').value;
    const saldo = parseFloat(document.getElementById('saldoCorrente').value);

    const contaCorrente = new Corrente(nome, banco, numeroConta, saldo);
    document.getElementById('dadosContaCorrente').innerHTML = contaCorrente.exibirDados();
}

// Função para Criar Conta Poupança
function criarContaPoupanca() {
    const nome = document.getElementById('nomePoupanca').value;
    const banco = document.getElementById('bancoPoupanca').value;
    const numeroConta = document.getElementById('numeroContaPoupanca').value;
    const saldo = parseFloat(document.getElementById('saldoPoupanca').value);
    const juros = parseFloat(document.getElementById('jurosPoupanca').value);
    const dataVencimento = document.getElementById('dataVencimentoPoupanca').value;

    const contaPoupanca = new Poupanca(nome, banco, numeroConta, saldo, juros, dataVencimento);
    document.getElementById('dadosContaPoupanca').innerHTML = contaPoupanca.exibirDados();
}