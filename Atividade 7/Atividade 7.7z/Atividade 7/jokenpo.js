function escolhaComputador() {
    const escolhas = ['pedra', 'papel', 'tesoura'];
    const escolhaAleatoria = Math.floor(Math.random() * 3);
    return escolhas[escolhaAleatoria];
}

function resultado(jogador, computador) {
    if (jogador === computador) {
        return '\nQUE AZAR, DEU EMPATE!\n';
    }

    if (
        (jogador === 'pedra' && computador === 'tesoura') ||
        (jogador === 'papel' && computador === 'pedra') ||
        (jogador === 'tesoura' && computador === 'papel')
    ) {
        return '\nMEUS PARABÉNS, VOCÊ GANHOU!\n';
    }

    return '\nVOCÊ É SIMPLESMENTE O PIOR!\n';
}

function jogar(jogador) {
    const computador = escolhaComputador();
    const resultadoJogo = resultado(jogador, computador);

    document.getElementById('gameResult').textContent = `Você escolheu ${jogador}. O computador escolheu ${computador}.`;
    document.getElementById('gameResult1').textContent = `Resultado: ${resultadoJogo}`;
}

document.getElementById('rock').addEventListener('click', () => jogar('pedra'));
document.getElementById('paper').addEventListener('click', () => jogar('papel'));
document.getElementById('scissors').addEventListener('click', () => jogar('tesoura'));
