let funcionario1 = {
  matricula: 123456,
  nome: "Thales Carro Ligado",
  funcao: "Profissional de Computaria"
};

let resultadoHTML = `
<h2>Objeto criado pela Forma 1 (Notação Literal):</h2>
<ul>
  <li><span>Matrícula:</span> ${funcionario1.matricula}</li>
  <li><span>Nome:</span> ${funcionario1.nome}</li>
  <li><span>Função:</span> ${funcionario1.funcao}</li>
</ul>
`;

function Funcionario(matricula, nome, funcao) {
  this.matricula = matricula;
  this.nome = nome;
  this.funcao = funcao;
}

let funcionario2 = new Funcionario(54321, "Pardinho", "Body Builder");

resultadoHTML += `
<h2>Objeto criado pela Forma 2 (Função Construtora):</h2>
<ul>
  <li><span>Matrícula:</span> ${funcionario2.matricula}</li>
  <li><span>Nome:</span> ${funcionario2.nome}</li>
  <li><span>Função:</span> ${funcionario2.funcao}</li>
</ul>
`;

let funcionario3 = Object.create(Object.prototype);
funcionario3.matricula = 124680;
funcionario3.nome = "Perry";
funcionario3.funcao = "Criador de Conteúdo";

resultadoHTML += `
<h2>Objeto criado pela Forma 3 (Object.create()):</h2>
<ul>
  <li><span>Matrícula:</span> ${funcionario3.matricula}</li>
  <li><span>Nome:</span> ${funcionario3.nome}</li>
  <li><span>Função:</span> ${funcionario3.funcao}</li>
</ul>
`;

document.getElementById('resultado').innerHTML = resultadoHTML;
