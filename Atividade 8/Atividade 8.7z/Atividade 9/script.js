let idadeUsuario = 0;
let generoUsuario = null;
let avaliacaoUsuario = null;
let totalPessoas = 0;
let somaIdades = 0;
let mediaIdadeUsuario = 0;
let idadeMaisVelha = 0;
let idadeMaisNova = 0;
let qtdRespostasPessimo = 0;
let qtdRespostasOtimo = 0;
let qtdRespostasBom = 0;
let porcentagemOtimo = 0;
let porcentagemBom = 0;
let qtdHomens = 0;
let qtdMulheres = 0;

const formularioPesquisa = document.getElementById("formPesquisa");
const divResultados = document.getElementById("resultados");
const mediaIdadeElemento = document.getElementById("mediaIdade");
const idadeMaisVelhaElemento = document.getElementById("maisVelha");
const idadeMaisNovaElemento = document.getElementById("maisNova");
const qtdPessimoElemento = document.getElementById("qtdPessimo");
const porcOtimoElemento = document.getElementById("porcOtimo");
const porcBomElemento = document.getElementById("porcBom");
const qtdHomensElemento = document.getElementById("numHomens");
const qtdMulheresElemento = document.getElementById("numMulheres");

function calcularResultados() {
    mediaIdadeUsuario = somaIdades / totalPessoas;
    porcentagemBom = (qtdRespostasBom / totalPessoas) * 100;
    porcentagemOtimo = (qtdRespostasOtimo / totalPessoas) * 100;

    mediaIdadeElemento.textContent = `Média de Idade: ${mediaIdadeUsuario.toFixed(2)}`;
    idadeMaisVelhaElemento.textContent = `Idade da Pessoa Mais Velha: ${idadeMaisVelha}`;
    idadeMaisNovaElemento.textContent = `Idade da Pessoa Mais Nova: ${idadeMaisNova}`;
    qtdPessimoElemento.textContent = `Quantidade de respostas Péssimo: ${qtdRespostasPessimo}`;
    porcOtimoElemento.textContent = `Porcentagem de respostas Ótimo: ${porcentagemOtimo.toFixed(2)}%`;
    porcBomElemento.textContent = `Porcentagem de respostas Bom: ${porcentagemBom.toFixed(2)}%`;
    qtdHomensElemento.textContent = `Número de Homens: ${qtdHomens}`;
    qtdMulheresElemento.textContent = `Número de Mulheres: ${qtdMulheres}`;

    divResultados.classList.remove("hidden");
}

formularioPesquisa.addEventListener("submit", function(event) {
    event.preventDefault(); 

    idadeUsuario = parseInt(document.getElementById("idade").value);
    generoUsuario = document.getElementById("sexo").value;
    avaliacaoUsuario = parseInt(document.getElementById("opiniao").value);

    somaIdades += idadeUsuario;
    totalPessoas++;

    if (totalPessoas === 1) {
        idadeMaisVelha = idadeUsuario;
        idadeMaisNova = idadeUsuario;
    } else {
        if (idadeUsuario > idadeMaisVelha) idadeMaisVelha = idadeUsuario;
        if (idadeUsuario < idadeMaisNova) idadeMaisNova = idadeUsuario;
    }

    if (avaliacaoUsuario === 1) qtdRespostasPessimo++;
    if (avaliacaoUsuario === 4) qtdRespostasOtimo++;
    if (avaliacaoUsuario === 3) qtdRespostasBom++;

    if (generoUsuario === "M") qtdHomens++;
    if (generoUsuario === "F") qtdMulheres++;

    formularioPesquisa.reset();
});

const btnVerificar = document.getElementById("verificar");
btnVerificar.addEventListener("click", calcularResultados);
